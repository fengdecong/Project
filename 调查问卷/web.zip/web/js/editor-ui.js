"use strict";

/*
pid: 0         基本信息页
pid > 0:       普通的调查问卷页
pid: -1        致谢页
 */
class EditorUI {
    currentPid = 0;
    tabs = document.querySelector("#tabs");
    contentPanel = document.querySelector("#content");

    getAddTabButton() {
        // 返回 html  中的 id=add-tab 的元素
        return document.querySelector("#add-tab");
    }

    addTab(pid, activeAction) {
        // <div>第 <pid> 页 <span>删除</span></div>
        let span = document.createElement("span");
        span.innerText = "删除";
        span.onclick = function (evt) {
            alert("hello world");

            evt.stopPropagation();  // 停止事件的传播——停止冒泡行为
        };

        let div = document.createElement("div");
        let text = document.createTextNode("第" + pid + "页");
        div.appendChild(text);
        div.appendChild(span);

        div.setAttribute("data-pid", pid);
        div.onclick = activeAction;     // 点击 tab 后，会激活该 tab

        this.tabs.appendChild(div);
    }

    inactive() {
        // 需要先确定之前的激活状态的 tab
        // 如何标识激活页 tab，通过添加 class="active"
        let currentActive = document.querySelector(".active");
        if (currentActive === null) {
            return;
        }

        currentActive.classList.remove("active");
        this.contentPanel.innerHTML = "";   // 视为把该元素的所有孩子全部删掉
    }

    active(pid, data) {
        this.currentPid = pid;

        let toActiveTab = document.querySelector("[data-pid='" + pid + "']");
        toActiveTab.classList.add("active");

        if (pid === 0) {
            this.showBasicContent(data);
        } else if (pid === -1) {
            this.showThanksContent(data);
        } else {
            this.showPageContent(pid, data);
        }
    }

    showBasicContent(data) {
        console.log(data);
    }

    showThanksContent(data) {
        console.log(data);
    }

    showPageContent(pid, data) {
        console.log(data);
    }

    getBasicTabButton() {
        return document.querySelector("#basic-tab");
    }

    getThanksTabButton() {
        return document.querySelector("#thanks-tab");
    }
}